# Elite Redux Korean Dex

Elite Redux 2.65.3b Korean STAGE433 기준 모바일 웹 도감입니다.

## GitHub Pages 배포

1. 이 폴더의 파일을 저장소 루트에 업로드합니다.
2. GitHub 저장소 **Settings → Pages**로 이동합니다.
3. **Deploy from a branch**를 선택합니다.
4. Branch는 `main`, Folder는 `/ (root)`를 선택하고 저장합니다.
5. 잠시 후 Pages 주소에서 접속할 수 있습니다.

`index.html`이 메인 페이지이며, 모바일 하단 탭/검색/타입 필터/한국어 폼명이 포함되어 있습니다.
