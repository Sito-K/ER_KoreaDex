Elite Redux Korean Dex STAGE3 MOBILE

모바일 최적화 빌드입니다.
- iPhone/Android 터치 UI
- 하단 5탭 내비게이션
- 상단 고정 검색
- 타입 필터 가로 스와이프
- 상세 화면 모바일 전체화면
- 한국어 폼 이름 STAGE2 규칙 포함
- 공개 기본 데이터는 인터넷 연결 시 CDN에서 자동 로드
- CDN 연결이 실패해도 STAGE433 한국어 이름/기술/특성/도구/트레이너 로컬 데이터는 표시

index.html: 일반 정적 사이트용
Elite_Redux_Korean_Dex_MOBILE_SINGLE.html: CSS/앱/한국어 데이터를 한 파일에 합친 모바일 전달용

공개 URL로 배포하려면 이 폴더 전체를 GitHub Pages / Cloudflare Pages / Netlify 같은 정적 호스팅에 올리면 됩니다.
