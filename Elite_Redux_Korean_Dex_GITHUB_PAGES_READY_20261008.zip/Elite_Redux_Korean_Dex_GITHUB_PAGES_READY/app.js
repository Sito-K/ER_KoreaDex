(() => {
'use strict';
const KO=window.KO_DATA;
const BASE_URLS=[
  'https://cdn.jsdelivr.net/gh/ForwardFeed/ER-nextdex@main/static/js/data/gameDataV2.65beta.json',
  'https://raw.githubusercontent.com/ForwardFeed/ER-nextdex/main/static/js/data/gameDataV2.65beta.json',
  'https://raw.githubusercontent.com/jdsmithb25/elite-redux-nextdex/main/gameDataV2.65beta.json'
];
const TYPE_COLORS=['#919aa2','#ce416b','#89aae3','#aa6bc8','#d97845','#c5b78c','#91c12f','#5269ad','#5a8ea2','#666','#ff9d55','#5090d6','#63bc5a','#f4d23c','#fa7179','#73cec0','#0b6dc3','#5a5465','#ec8fe6','#7b6cf6'];
const $=s=>document.querySelector(s); const $$=s=>[...document.querySelectorAll(s)];
const state={data:null,col:{species:[],moves:[],abilities:[],items:[],trainers:[]},view:'pokemon',query:'',type:null,sort:'id',limit:180};

function esc(s=''){return String(s).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function norm(s=''){return String(s).toLowerCase().replace(/[\s·._'’\-–—():]/g,'');}
const SPECIES_BASE_ENTRIES=Object.entries(KO.speciesByEn||{}).filter(([,v])=>v?.ko).sort((a,b)=>b[0].length-a[0].length);
const SPECIES_FORM_CACHE=new Map();
const FORM_WHOLE_KO={
  'mega':'메가진화','mega x':'메가진화 X','mega y':'메가진화 Y','mega z':'메가진화 Z',
  'redux':'리덕스폼','redux form':'리덕스폼','redux mega':'리덕스 메가진화','redux mega x':'리덕스 메가진화 X','redux mega y':'리덕스 메가진화 Y','redux mega z':'리덕스 메가진화 Z',
  'alola':'알로라의 모습','alolan':'알로라의 모습','galar':'가라르의 모습','galarian':'가라르의 모습','hisui':'히스이의 모습','hisuian':'히스이의 모습','paldea':'팔데아의 모습','paldean':'팔데아의 모습',
  'primal':'원시회귀','origin':'오리진폼','origin forme':'오리진폼','altered':'어나더폼','altered forme':'어나더폼',
  'attack':'어택폼','attack forme':'어택폼','defense':'디펜스폼','defence':'디펜스폼','defense forme':'디펜스폼','speed':'스피드폼','speed forme':'스피드폼',
  'plant cloak':'초목도롱','sandy cloak':'모래땅도롱','trash cloak':'슈레도롱','sunshine':'포지폼','overcast':'네거폼',
  'east sea':'동쪽바다','west sea':'서쪽바다','heat':'히트폼','wash':'워시폼','frost':'프로스트폼','fan':'스핀폼','mow':'커트폼',
  'sky':'스카이폼','land':'랜드폼','therian':'영물폼','therian forme':'영물폼','incarnate':'화신폼','incarnate forme':'화신폼',
  'white':'화이트폼','black':'블랙폼','resolute':'각오의 모습','resolute form':'각오의 모습','ordinary':'평상시 모습','pirouette':'스텝폼',
  'red striped':'적색근의 모습','blue striped':'청색근의 모습','white striped':'백색근의 모습',
  'zen':'달마모드','zen mode':'달마모드','galar zen':'가라르 달마모드','galarian zen':'가라르 달마모드',
  'spring':'봄의 모습','summer':'여름의 모습','autumn':'가을의 모습','winter':'겨울의 모습',
  'female':'암컷','male':'수컷','blade':'블레이드폼','blade forme':'블레이드폼','shield':'실드폼','shield forme':'실드폼',
  'small':'작은 사이즈','small size':'작은 사이즈','average':'보통 사이즈','average size':'보통 사이즈','large':'큰 사이즈','large size':'큰 사이즈','super':'특대 사이즈','super size':'특대 사이즈',
  'confined':'굴레에 빠진 모습','unbound':'굴레를 벗어난 모습','ash':'지우폼','ash greninja':'지우개굴닌자','battle bond':'유대변화',
  '10':'10%폼','10%':'10%폼','10 percent':'10%폼','50':'50%폼','50%':'50%폼','complete':'퍼펙트폼','complete form':'퍼펙트폼',
  'baile':'이글이글스타일','pom pom':'파칙파칙스타일','pau':'훌라훌라스타일','pa u':'훌라훌라스타일','sensu':'하늘하늘스타일',
  'midday':'한낮의 모습','midnight':'한밤중의 모습','dusk':'황혼의 모습','school':'군집의 모습','solo':'단독의 모습',
  'meteor':'유성의 모습','core':'코어의 모습','red core':'빨강 코어','orange core':'주황 코어','yellow core':'노랑 코어','green core':'초록 코어','blue core':'파랑 코어','indigo core':'남색 코어','violet core':'보라 코어',
  'dusk mane':'황혼의 갈기','dawn wings':'새벽의 날개','ultra':'울트라폼','original color':'500년 전의 색',
  'gulping':'그대로삼킨 모습','gorging':'통째로삼킨 모습','amped':'하이한 모습','amped form':'하이한 모습','low key':'로우한 모습','low key form':'로우한 모습',
  'phony':'가품','antique':'진품','ice face':'아이스페이스','noice face':'나이스페이스','noice':'나이스페이스','hangry':'배고픈 모습',
  'crowned sword':'검왕의 모습','crowned shield':'방패왕의 모습','crowned':'왕의 모습','eternamax':'무한다이맥스',
  'single strike':'일격의 태세','single strike style':'일격의 태세','rapid strike':'연격의 태세','rapid strike style':'연격의 태세','dada':'아빠 모습',
  'ice rider':'백마 탄 모습','shadow rider':'흑마 탄 모습',
  'family of three':'3마리 가족','family of four':'4마리 가족','three family':'3마리 가족','four family':'4마리 가족',
  'green plumage':'그린 페더','blue plumage':'블루 페더','yellow plumage':'옐로 페더','white plumage':'화이트 페더',
  'hero':'마이티폼','hero form':'마이티폼','zero':'나이브폼','zero form':'나이브폼',
  'curly':'늘어진 모습','droopy':'처진 모습','stretchy':'뻗은 모습',
  'two segment':'두 마디폼','two segment form':'두 마디폼','three segment':'세 마디폼','three segment form':'세 마디폼',
  'chest':'상자폼','chest form':'상자폼','roaming':'도보폼','roaming form':'도보폼',
  'counterfeit':'위작','artisan':'고상한 모습','unremarkable':'범작','masterpiece':'걸작',
  'teal mask':'벽록의 가면','hearthflame mask':'화덕의 가면','wellspring mask':'우물의 가면','cornerstone mask':'주춧돌의 가면',
  'teal':'벽록의 가면','hearthflame':'화덕의 가면','wellspring':'우물의 가면','cornerstone':'주춧돌의 가면',
  'terastal':'테라스탈폼','stellar':'스텔라폼','bloodmoon':'붉은 달의 모습',
  'original cap':'오리지널캡','hoenn cap':'호연캡','sinnoh cap':'신오캡','unova cap':'하나캡','kalos cap':'칼로스캡','alola cap':'알로라캡','partner cap':'너로정했다캡','world cap':'월드캡',
  'cosplay':'코스프레','rock star':'하드록','belle':'마담','pop star':'아이돌','phd':'닥터','libre':'마스크드',
  'bond phenomenon':'유대현상','power construct':'스웜체인지',
  'gigantamax':'거다이맥스','gmax':'거다이맥스',
  'sunny':'태양의 모습','rainy':'빗방울의 모습','snowy':'설운의 모습',
  'douse drive':'아쿠아카세트','shock drive':'번개카세트','burn drive':'블레이즈카세트','chill drive':'프리즈카세트',
  'disguised':'둔갑한 모습','busted':'들킨 모습','totem':'주인 포켓몬',
  'combat breed':'컴뱃종','blaze breed':'블레이즈종','aqua breed':'워터종','paldean combat breed':'팔데아의 모습·컴뱃종','paldean blaze breed':'팔데아의 모습·블레이즈종','paldean aqua breed':'팔데아의 모습·워터종',
  'archipelago pattern':'군도문양','continental pattern':'대륙문양','elegant pattern':'우아문양','garden pattern':'정원문양','high plains pattern':'황야문양','icy snow pattern':'설국문양','jungle pattern':'정글문양','marine pattern':'마린문양','modern pattern':'모던문양','monsoon pattern':'스콜문양','ocean pattern':'대양문양','polar pattern':'빙설문양','river pattern':'큰강문양','sandstorm pattern':'사진문양','savanna pattern':'사바나문양','sun pattern':'태양문양','tundra pattern':'설원문양','fancy pattern':'팬시한 모양','poke ball pattern':'볼의 모양','pokeball pattern':'볼의 모양',
  'heart trim':'하트컷','star trim':'스타컷','diamond trim':'다이아컷','debutante trim':'레이디컷','matron trim':'마담컷','dandy trim':'젠틀컷','la reine trim':'퀸컷','kabuki trim':'가부키컷','pharaoh trim':'킹덤컷',
  'vanilla cream':'바닐라크림','ruby cream':'루비믹스','matcha cream':'말차크림','mint cream':'민트크림','lemon cream':'레몬크림','salted cream':'솔트크림','ruby swirl':'루비솔트','caramel swirl':'캐러멜믹스','rainbow swirl':'트리플믹스'
};
const FORM_TOKEN_KO={
  mega:'메가',redux:'리덕스',form:'폼',forme:'폼',alola:'알로라',alolan:'알로라',galar:'가라르',galarian:'가라르',hisui:'히스이',hisuian:'히스이',paldea:'팔데아',paldean:'팔데아',
  primal:'원시',origin:'오리진',altered:'어나더',attack:'어택',defense:'디펜스',defence:'디펜스',speed:'스피드',plant:'초목',sandy:'모래땅',trash:'슈레',cloak:'도롱',sunshine:'포지',overcast:'네거',
  east:'동쪽',west:'서쪽',sea:'바다',heat:'히트',wash:'워시',frost:'프로스트',fan:'스핀',mow:'커트',sky:'스카이',land:'랜드',therian:'영물',incarnate:'화신',white:'화이트',black:'블랙',resolute:'각오',ordinary:'평상시',pirouette:'스텝',
  red:'빨강',blue:'파랑',green:'초록',yellow:'노랑',orange:'주황',indigo:'남색',violet:'보라',pink:'분홍',brown:'갈색',gray:'회색',grey:'회색',striped:'근',zen:'달마',spring:'봄',summer:'여름',autumn:'가을',winter:'겨울',
  female:'암컷',male:'수컷',blade:'블레이드',shield:'실드',small:'작은',average:'보통',large:'큰',super:'특대',size:'사이즈',confined:'굴레',unbound:'해방',ash:'지우',battle:'배틀',bond:'유대',complete:'퍼펙트',
  baile:'이글이글',pom:'파칙파칙',pau:'훌라훌라',sensu:'하늘하늘',midday:'한낮',midnight:'한밤중',dusk:'황혼',school:'군집',solo:'단독',meteor:'유성',core:'코어',mane:'갈기',dawn:'새벽',wings:'날개',ultra:'울트라',original:'오리지널',color:'색',
  gulping:'그대로삼킨',gorging:'통째로삼킨',amped:'하이',low:'로우',key:'키',phony:'가품',antique:'진품',ice:'얼음',noice:'나이스',face:'페이스',hangry:'배고픈',crowned:'왕',sword:'검',rapid:'연격',single:'일격',strike:'태세',style:'스타일',dada:'아빠',rider:'탄',shadow:'흑마',
  family:'가족',three:'3',four:'4',plumage:'깃털',hero:'마이티',zero:'나이브',curly:'늘어진',droopy:'처진',stretchy:'뻗은',segment:'마디',chest:'상자',roaming:'도보',counterfeit:'위작',artisan:'고상한',unremarkable:'범작',masterpiece:'걸작',
  teal:'벽록',hearthflame:'화덕',wellspring:'우물',cornerstone:'주춧돌',mask:'가면',terastal:'테라스탈',stellar:'스텔라',bloodmoon:'붉은달',cap:'캡',partner:'너로정했다',world:'월드',gigantamax:'거다이맥스',gmax:'거다이맥스',
  sunny:'태양',rainy:'비',snowy:'눈',drive:'카세트',douse:'아쿠아',shock:'번개',burn:'블레이즈',chill:'프리즈',disguised:'둔갑',busted:'들킨',totem:'주인',combat:'컴뱃',breed:'종',blaze:'블레이즈',aqua:'워터',pattern:'문양',trim:'컷',heart:'하트',star:'스타',diamond:'다이아',debutante:'레이디',matron:'마담',dandy:'젠틀',reine:'퀸',kabuki:'가부키',pharaoh:'킹덤',cream:'크림',ruby:'루비',matcha:'말차',mint:'민트',lemon:'레몬',salted:'솔트',swirl:'믹스',rainbow:'트리플',caramel:'캐러멜',strawberry:'딸기',berry:'베리',love:'러브',clover:'클로버',flower:'플라워',ribbon:'리본',sweet:'사탕',normal:'노말',fighting:'격투',flying:'비행',poison:'독',ground:'땅',rock:'바위',bug:'벌레',ghost:'고스트',steel:'강철',fire:'불꽃',water:'물',grass:'풀',electric:'전기',psychic:'에스퍼',dragon:'드래곤',dark:'악',fairy:'페어리',stellar:'스텔라'
};
function cleanFormDesc(s=''){return String(s).replace(/[_–—-]+/g,' ').replace(/[()]/g,' ').replace(/\s+/g,' ').trim();}
function findSpeciesBase(mon){
  const en=String(mon?.name||'').trim();
  const exact=KO.speciesByEn[en]; if(exact?.ko)return {en,ko:exact.ko,desc:''};
  const lower=` ${en.toLowerCase()} `;
  for(const [base,v] of SPECIES_BASE_ENTRIES){
    const idx=lower.indexOf(` ${base.toLowerCase()} `);
    if(idx>=0){const realIdx=Math.max(0,idx);const before=en.slice(0,realIdx).trim();const after=en.slice(realIdx+base.length).trim();return {en:base,ko:v.ko,desc:cleanFormDesc(`${before} ${after}`)};}
  }
  // Internal species constants are often more regular than display names.
  const code=String(mon?.NAME||'').replace(/^SPECIES_/,'');
  if(code){
    const canon=s=>String(s).toUpperCase().replace(/[^A-Z0-9]+/g,'_').replace(/^_|_$/g,'');
    for(const [base,v] of SPECIES_BASE_ENTRIES){const b=canon(base);if(code===b||code.startsWith(b+'_'))return {en:base,ko:v.ko,desc:cleanFormDesc(code.slice(b.length).replace(/^_/,''))};}
  }
  return null;
}
function translateFormDesc(desc){
  const key=cleanFormDesc(desc).toLowerCase().replace(/[.'’]/g,'').trim();
  if(!key)return '';
  if(FORM_WHOLE_KO[key])return FORM_WHOLE_KO[key];
  const toks=key.split(/\s+/).filter(Boolean); const out=[];
  for(const t of toks){if(/^\d+%?$/.test(t)){out.push(t.replace(/%?$/,'%'));continue;}if(/^[xyz]$/.test(t)){out.push(t.toUpperCase());continue;}const k=FORM_TOKEN_KO[t];if(!k)return null;out.push(k);}
  return out.join(' ');
}
function formatKoreanForm(baseKo,desc,mon){
  const key=cleanFormDesc(desc).toLowerCase().replace(/[.'’]/g,'').trim();
  if(!key)return baseKo;
  if(/^mega(?:\s+[xyz])?$/.test(key)){const l=key.match(/\b([xyz])$/)?.[1]?.toUpperCase()||'';return `메가${baseKo}${l}`;}
  if(/^redux mega(?:\s+[xyz])?$/.test(key)){const l=key.match(/\b([xyz])$/)?.[1]?.toUpperCase()||'';return `메가${baseKo}${l} (리덕스)`;}
  if(key==='primal')return `원시${baseKo}`;
  if(key==='gigantamax'||key==='gmax')return `거다이맥스${baseKo}`;
  if(baseKo==='로토무'&&['heat','wash','frost','fan','mow'].includes(key))return ({heat:'히트로토무',wash:'워시로토무',frost:'프로스트로토무',fan:'스핀로토무',mow:'커트로토무'})[key];
  if(baseKo==='큐레무'&&key==='white')return '화이트큐레무';
  if(baseKo==='큐레무'&&key==='black')return '블랙큐레무';
  if(baseKo==='개굴닌자'&&key==='ash')return '지우개굴닌자';
  if(baseKo==='네크로즈마'&&key==='ultra')return '울트라네크로즈마';
  if(baseKo==='마기아나'&&key==='original')return '마기아나 (500년 전의 색)';
  if(baseKo==='자시안'&&key==='crowned')return '자시안 (검왕의 모습)';
  if(baseKo==='자마젠타'&&key==='crowned')return '자마젠타 (방패왕의 모습)';
  if(/^[a-z]$/i.test(key))return `${baseKo} (${key.toUpperCase()}형)`;
  if(['alola','alolan'].includes(key))return `${baseKo} (알로라의 모습)`;
  if(['galar','galarian'].includes(key))return `${baseKo} (가라르의 모습)`;
  if(['hisui','hisuian'].includes(key))return `${baseKo} (히스이의 모습)`;
  if(['paldea','paldean'].includes(key))return `${baseKo} (팔데아의 모습)`;
  const ko=translateFormDesc(desc);
  return `${baseKo} (${ko||`특수폼 #${mon?.id??'?'}`})`;
}
function koSpeciesName(mon){
  const cacheKey=`${mon?.id??''}|${mon?.name??''}|${mon?.NAME??''}`; if(SPECIES_FORM_CACHE.has(cacheKey))return SPECIES_FORM_CACHE.get(cacheKey);
  const exact=KO.speciesByEn[mon?.name]; let result;
  if(exact?.ko) result=exact.ko;
  else {const base=findSpeciesBase(mon); result=base?formatKoreanForm(base.ko,base.desc,mon):`포켓몬 ${mon?.id??'?'}`;}
  SPECIES_FORM_CACHE.set(cacheKey,result); return result;
}
function koMove(m){const x=KO.moves[m?.id];return x?.ko||m?.name||'알 수 없음';}
function koAbility(a){const id=typeof a==='number'?a:a?.id;const x=KO.abilities[id];return x?.ko||a?.name||`특성 ${id}`;}
function koItem(i){const id=typeof i==='number'?i:i?.id;const x=KO.items[id];return x?.ko||i?.name||`도구 ${id}`;}
function typeName(id){return KO.types[id]||`타입 ${id}`;}
function typeBadge(id){return `<span class="type" style="background:${TYPE_COLORS[id]||'#666'}">${esc(typeName(id))}</span>`;}
function spriteUrl(mon){const name=(mon.NAME||'').replace(/^SPECIES_/,'');return `https://cdn.jsdelivr.net/gh/ForwardFeed/ER-nextdex@main/static/sprites/${encodeURIComponent(name)}.png`;}
function splitName(v){return ['물리','특수','변화'][v]||`분류 ${v}`;}
function findArrayByPrefix(data,prefix){for(const [k,v] of Object.entries(data||{})){if(Array.isArray(v)&&v.some(x=>x&&typeof x==='object'&&String(x.NAME||'').startsWith(prefix)))return v;}return [];}
function detect(data){
  const species=data.species||findArrayByPrefix(data,'SPECIES_');
  const moves=data.moves||findArrayByPrefix(data,'MOVE_');
  const abilities=data.abilities||findArrayByPrefix(data,'ABILITY_');
  const items=data.items||findArrayByPrefix(data,'ITEM_');
  let trainers=data.trainers||[];
  if(!trainers.length){for(const v of Object.values(data||{})){if(Array.isArray(v)&&v.some(x=>x&&typeof x==='object'&&(x.party||x.mons||x.pokemon)&&('name'in x||'NAME'in x))){trainers=v;break;}}}
  return {species,moves,abilities,items,trainers};
}
async function loadBase(){
  for(const url of BASE_URLS){try{const c=new AbortController();const t=setTimeout(()=>c.abort(),15000);const r=await fetch(url,{signal:c.signal,cache:'force-cache'});clearTimeout(t);if(!r.ok)throw Error(r.status);return await r.json();}catch(e){console.warn('base load failed',url,e);}}
  return null;
}
function setStatus(kind,text){$('#statusBar .dot').className=`dot ${kind||''}`;$('#statusText').textContent=text;}
function prepare(){
  const d=state.data; const dc=d?detect(d):{species:[],moves:[],abilities:[],items:[],trainers:[]};
  state.col.species=(dc.species.length?dc.species:KO.speciesFallback||[]).filter(x=>x&&x.name&&x.id!==-1);
  state.col.moves=dc.moves.filter(x=>x&&x.id!==undefined);
  state.col.abilities=dc.abilities.filter(x=>x&&x.id!==undefined);
  state.col.items=(dc.items.length?dc.items:Object.values(KO.items)).filter(Boolean);
  state.col.trainers=(dc.trainers.length?dc.trainers:KO.trainers).filter(Boolean);
  // If base abilities/moves failed, use Korean local database so the site remains useful.
  if(!state.col.moves.length) state.col.moves=Object.values(KO.moves);
  if(!state.col.abilities.length) state.col.abilities=Object.values(KO.abilities);
  ['Pokemon','Moves','Abilities','Items','Trainers'].forEach((n,i)=>$('#count'+n).textContent=[state.col.species.length,state.col.moves.length,state.col.abilities.length,state.col.items.length,state.col.trainers.length][i].toLocaleString());
  const c=KO.meta.counts; $('#heroStats').innerHTML=[['포켓몬명',c.speciesNames],['기술',c.moves],['특성',c.abilities]].map(x=>`<div class="hero-stat"><b>${x[1].toLocaleString()}</b><span>${x[0]}</span></div>`).join('');
}
function renderFilters(){
  const el=$('#typeFilters'); if(!['pokemon','moves'].includes(state.view)){el.innerHTML='';return;}
  el.innerHTML=`<button class="filter-chip ${state.type===null?'active':''}" data-type="">전체</button>`+KO.types.filter((_,i)=>i!==9).map((t,i0)=>{const i=i0<9?i0:i0+1;return `<button class="filter-chip ${state.type===i?'active':''}" data-type="${i}">${esc(t)}</button>`}).join('');
  $$('.filter-chip').forEach(b=>b.onclick=()=>{state.type=b.dataset.type===''?null:Number(b.dataset.type);state.limit=180;render();});
}
function searchableName(view,x){
  if(view==='pokemon')return `${koSpeciesName(x)} ${x.name} ${x.NAME||''}`;
  if(view==='moves'){const k=KO.moves[x.id]||{};return `${k.ko||x.name||''} ${x.name||k.en||''} ${k.short||''} ${k.long||''}`;}
  if(view==='abilities'){const k=KO.abilities[x.id]||{};return `${k.ko||x.name||''} ${x.name||k.en||''} ${k.short||''} ${k.long||''}`;}
  if(view==='items'){const k=KO.items[x.id]||x;return `${k.ko||x.name||''} ${x.name||k.en||''} ${k.desc||''}`;}
  if(view==='trainers'){const k=KO.trainers.find(t=>t.id===x.id)||x;return `${k.ko||x.name||''} ${x.name||k.en||''}`;}
  return '';
}
function filtered(){
  const map={pokemon:'species',moves:'moves',abilities:'abilities',items:'items',trainers:'trainers'}; let a=[...state.col[map[state.view]]];
  if(state.query){const q=norm(state.query);a=a.filter(x=>norm(searchableName(state.view,x)).includes(q));}
  if(state.type!==null){if(state.view==='pokemon')a=a.filter(x=>(x.stats?.types||[]).includes(state.type));if(state.view==='moves')a=a.filter(x=>(x.types||[]).includes(state.type));}
  if(state.view==='pokemon'){
    a.sort((a,b)=>state.sort==='name'?koSpeciesName(a).localeCompare(koSpeciesName(b),'ko'):state.sort==='bst'?sumStats(b)-sumStats(a):(a.id??99999)-(b.id??99999));
  } else if(state.sort==='name') a.sort((a,b)=>searchableName(state.view,a).localeCompare(searchableName(state.view,b),'ko'));
  else a.sort((a,b)=>(a.id??99999)-(b.id??99999));
  return a;
}
function sumStats(m){return (m.stats?.base||[]).reduce((a,b)=>a+(+b||0),0);}
function pokemonCard(m){const k=koSpeciesName(m);const types=m.stats?.types||[];return `<article class="card pokemon-card" data-kind="pokemon" data-id="${m.id}"><div class="sprite-box"><img class="sprite" loading="lazy" src="${spriteUrl(m)}" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span class="sprite-fallback" style="display:none">NO IMAGE</span></div><div><span class="num">#${String(m.dex?.id??m.id).padStart(4,'0')}</span><h3>${esc(k)}</h3><div class="en-name">${esc(m.name)}</div><div class="types">${[...new Set(types)].map(typeBadge).join('')}</div><div class="bst">BST <b>${sumStats(m)}</b></div></div></article>`;}
function moveCard(m){const k=KO.moves[m.id]||{};const types=m.types||[];return `<article class="card text-card" data-kind="move" data-id="${m.id}"><span class="num">#${m.id}</span><h3>${esc(k.ko||m.name||k.en||'')}</h3><div class="en-name">${esc(m.name||k.en||'')}</div><div class="move-meta">${types.map(typeBadge).join('')}<span class="pill">${esc(splitName(m.split))}</span>${m.pwr!==undefined?`<span class="pill">위력 ${m.pwr||'—'}</span>`:''}</div><div class="desc">${esc(k.short||m.desc||k.long||'')}</div></article>`;}
function abilityCard(a){const k=KO.abilities[a.id]||{};return `<article class="card text-card" data-kind="ability" data-id="${a.id}"><span class="num">#${a.id}</span><h3>${esc(k.ko||a.name||k.en||'')}</h3><div class="en-name">${esc(a.name||k.en||'')}</div><div class="desc">${esc(k.short||k.long||a.desc||'')}</div></article>`;}
function itemCard(i){const k=KO.items[i.id]||i;return `<article class="card text-card" data-kind="item" data-id="${i.id}"><span class="num">#${i.id}</span><h3>${esc(k.ko||i.name||k.en||'')}</h3><div class="en-name">${esc(i.name||k.en||'')}</div><div class="desc">${esc(k.desc||'')}</div></article>`;}
function trainerCard(t){const k=KO.trainers.find(x=>x.id===t.id)||t;return `<article class="card text-card" data-kind="trainer" data-id="${t.id}"><span class="num">TRAINER #${t.id}</span><h3>${esc(k.ko||t.name||k.en||'이름 없음')}</h3><div class="en-name">${esc(t.name||k.en||'')}</div>${k.classId!==undefined?`<div class="move-meta"><span class="pill">등급 ID ${k.classId??'—'}</span></div>`:''}</article>`;}
function render(){
  $$('.nav').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view));
  const titles={pokemon:['포켓몬','종족값 · 타입 · 특성 · Innate · 기술 · 진화'],moves:['기술','위력 · 명중 · PP · 설명 · 습득 포켓몬'],abilities:['특성','한국어 설명 · 보유 포켓몬 역검색'],items:['도구','한국어 이름 · 실제 ROM 설명'],trainers:['트레이너','STAGE433 실제 한국어 트레이너명']};
  $('#viewTitle').textContent=titles[state.view][0];$('#viewSubtitle').textContent=titles[state.view][1];
  $('#sortSelect').style.display=['pokemon','moves'].includes(state.view)?'block':'none';
  renderFilters();
  const all=filtered();const shown=all.slice(0,state.limit);$('#viewSubtitle').textContent+=` · ${all.length.toLocaleString()}개`;
  const fn={pokemon:pokemonCard,moves:moveCard,abilities:abilityCard,items:itemCard,trainers:trainerCard}[state.view];
  $('#results').className='grid '+(state.view==='pokemon'?'':'text-grid');$('#results').innerHTML=shown.map(fn).join('');
  $('#empty').classList.toggle('hidden',all.length!==0); bindCards();
  if(all.length>state.limit){const more=document.createElement('button');more.className='filter-chip';more.style='grid-column:1/-1;margin:12px auto';more.textContent=`더 보기 (${Math.min(180,all.length-state.limit)}개)`;more.onclick=()=>{state.limit+=180;render();};$('#results').appendChild(more);}
}
function bindCards(){$$('#results [data-kind]').forEach(el=>el.onclick=()=>openDetail(el.dataset.kind,Number(el.dataset.id)));}
function getSpecies(id){return state.col.species.find(x=>x.id===id);}
function getMove(id){return state.col.moves.find(x=>x.id===id)||{id,...(KO.moves[id]||{})};}
function getAbility(id){return state.col.abilities.find(x=>x.id===id)||{id,...(KO.abilities[id]||{})};}
function showModal(html){$('#modalContent').innerHTML=html;$('#modalBackdrop').classList.remove('hidden');document.body.style.overflow='hidden';bindModalLinks();}
function closeModal(){$('#modalBackdrop').classList.add('hidden');document.body.style.overflow='';}
function abilityBox(id,innate=false){const a=getAbility(id),k=KO.abilities[id]||{};return `<div class="ability-card ${innate?'innate':''}" data-link-kind="ability" data-link-id="${id}"><b>${esc(k.ko||a.name||'')}</b><span>${innate?'INNATE':'ABILITY'} · ${esc(a.name||k.en||'')}</span></div>`;}
function moveRows(list){return (list||[]).map(x=>{const m=getMove(typeof x==='number'?x:x.id);const k=KO.moves[m.id]||{};return `<tr class="click-row" data-link-kind="move" data-link-id="${m.id}"><td>${typeof x==='object'&&x.lv!==undefined?x.lv:'—'}</td><td><b>${esc(k.ko||m.name||'')}</b><br><span class="en-name">${esc(m.name||k.en||'')}</span></td><td>${(m.types||[]).map(typeBadge).join('')}</td><td>${m.pwr??'—'}</td><td>${m.acc===0?'—':(m.acc??'—')}</td><td>${m.pp??'—'}</td></tr>`;}).join('');}
function pokemonDetail(m){
  const ko=koSpeciesName(m),stats=m.stats?.base||[],dex=KO.dex[m.dex?.id]||{},evol=m.evolutions||[],abis=m.stats?.abis||[],inns=m.stats?.inns||[];
  const evHtml=evol.length?evol.map(e=>{const target=getSpecies(e.in);return `<span class="tag" ${target?`data-link-kind="pokemon" data-link-id="${target.id}"`:''}>${target?esc(koSpeciesName(target)):esc(String(e.in))} · ${esc(String(e.rs||''))}</span>`}).join(''):'진화 없음';
  const encounters=(m.SEnc||[]).length?`<div class="section"><h2>출현 데이터</h2><div>${[...new Set(m.SEnc.map(e=>e.map))].map(id=>`<span class="tag">맵 ID ${id}</span>`).join('')}</div></div>`:'';
  return `<div class="detail"><div class="detail-head"><img class="detail-sprite" src="${spriteUrl(m)}" onerror="this.style.opacity=.12"><div><span class="num">DEX #${m.dex?.id??'—'} · SPECIES ID ${m.id}</span><h1>${esc(ko)}</h1><div class="sub">${esc(m.name)} · ${esc(m.NAME||'')}</div><div class="types">${[...new Set(m.stats?.types||[])].map(typeBadge).join('')}</div><div class="bst">종족값 합계 <b>${sumStats(m)}</b></div></div></div>
  <div class="section"><h2>종족값</h2><div class="stats">${stats.map((v,i)=>`<div class="stat"><span>${esc(KO.stats[i])}</span><b>${v}</b><div class="bar"><i style="width:${Math.min(100,(v/180)*100)}%"></i></div></div>`).join('')}</div></div>
  <div class="section"><h2>특성</h2><div class="ability-grid">${abis.map(id=>abilityBox(id,false)).join('')}</div></div>
  <div class="section"><h2>Innate</h2><div class="ability-grid">${inns.map(id=>abilityBox(id,true)).join('')}</div></div>
  <div class="section"><h2>진화</h2><div>${evHtml}</div></div>
  ${(dex.desc||m.dex?.desc)?`<div class="section"><h2>도감 설명${dex.category?` · ${esc(dex.category)}포켓몬`:''}</h2><div class="dex-text">${esc(dex.desc||m.dex.desc)}</div></div>`:''}
  <div class="section"><h2>레벨업 기술</h2><div class="table-wrap"><table class="data-table"><thead><tr><th>레벨</th><th>기술</th><th>타입</th><th>위력</th><th>명중</th><th>PP</th></tr></thead><tbody>${moveRows(m.levelUpMoves)}</tbody></table></div></div>
  <div class="section"><h2>튜터 기술</h2><div>${(m.tutor||[]).map(id=>{const mv=getMove(id),k=KO.moves[id]||{};return `<span class="tag" data-link-kind="move" data-link-id="${id}">${esc(k.ko||mv.name||id)}</span>`}).join('')||'없음'}</div></div>${encounters}
  <div class="source-note">기본 전투 데이터: ER-nextdex 2.65 beta · 한국어 텍스트: STAGE433 ROM Sync Master</div></div>`;
}
function moveDetail(m){const k=KO.moves[m.id]||{};const users=state.col.species.filter(s=>(s.levelUpMoves||[]).some(x=>x.id===m.id)||(s.tutor||[]).includes(m.id)||(s.TMHMMoves||[]).includes(m.id)||(s.eggMoves||[]).includes(m.id));return `<div class="detail-simple"><span class="num">MOVE #${m.id}</span><h1>${esc(k.ko||m.name||k.en||'')}</h1><div class="sub">${esc(m.name||k.en||'')}</div><div class="move-meta">${(m.types||[]).map(typeBadge).join('')}<span class="pill">${esc(splitName(m.split))}</span><span class="pill">위력 ${m.pwr??'—'}</span><span class="pill">명중 ${m.acc===0?'—':(m.acc??'—')}</span><span class="pill">PP ${m.pp??'—'}</span><span class="pill">우선도 ${m.prio??0}</span></div><div class="desc">${esc(k.long||k.short||m.lDesc||m.desc||'설명 없음')}</div>${users.length?`<div class="section"><h2>습득 포켓몬 · ${users.length}종/폼</h2><div>${users.slice(0,180).map(s=>`<span class="tag" data-link-kind="pokemon" data-link-id="${s.id}">${esc(koSpeciesName(s))}</span>`).join('')}</div></div>`:''}<div class="source-note">한국어 기술명/설명은 STAGE433 실제 ROM 동기화 값 우선.</div></div>`;}
function abilityDetail(a){const k=KO.abilities[a.id]||{};const users=state.col.species.filter(s=>(s.stats?.abis||[]).includes(a.id)||(s.stats?.inns||[]).includes(a.id));return `<div class="detail-simple"><span class="num">ABILITY #${a.id}</span><h1>${esc(k.ko||a.name||k.en||'')}</h1><div class="sub">${esc(a.name||k.en||'')}</div><div class="desc">${esc(k.long||k.short||a.desc||'설명 없음')}</div>${users.length?`<div class="section"><h2>보유 포켓몬 · ${users.length}종/폼</h2><div>${users.slice(0,220).map(s=>`<span class="tag" data-link-kind="pokemon" data-link-id="${s.id}">${esc(koSpeciesName(s))}</span>`).join('')}</div></div>`:''}<div class="source-note">긴 설명은 STAGE433 한국어 특성 상세 설명을 우선 표시.</div></div>`;}
function itemDetail(i){const k=KO.items[i.id]||i;return `<div class="detail-simple"><span class="num">ITEM #${i.id}</span><h1>${esc(k.ko||i.name||k.en||'')}</h1><div class="sub">${esc(i.name||k.en||'')}</div><div class="desc">${esc(k.desc||'설명 없음')}</div><div class="source-note">아이템명/설명은 STAGE433 실제 ROM 출력문 기준.</div></div>`;}
function trainerDetail(t){const k=KO.trainers.find(x=>x.id===t.id)||t;const party=t.party||t.mons||t.pokemon||[];return `<div class="detail-simple"><span class="num">TRAINER #${t.id}</span><h1>${esc(k.ko||t.name||k.en||'이름 없음')}</h1><div class="sub">${esc(t.name||k.en||'')} ${k.classId!==undefined?`· 등급 ID ${k.classId}`:''}</div>${party.length?`<div class="section"><h2>파티</h2><pre class="dex-text">${esc(JSON.stringify(party,null,2))}</pre></div>`:'<div class="desc">현재 1차 빌드에서는 트레이너 이름을 ROM 기준으로 제공하며, 파티 구조는 공개 데이터에 존재할 때 자동 표시됩니다.</div>'}</div>`;}
function openDetail(kind,id){let html='';if(kind==='pokemon'){const x=getSpecies(id);if(x)html=pokemonDetail(x);}if(kind==='move')html=moveDetail(getMove(id));if(kind==='ability')html=abilityDetail(getAbility(id));if(kind==='item'){const x=state.col.items.find(v=>v.id===id)||KO.items[id];html=itemDetail(x);}if(kind==='trainer'){const x=state.col.trainers.find(v=>v.id===id)||KO.trainers.find(v=>v.id===id);html=trainerDetail(x);}if(html)showModal(html);}
function bindModalLinks(){$$('#modalContent [data-link-kind]').forEach(el=>el.onclick=e=>{e.stopPropagation();openDetail(el.dataset.linkKind,Number(el.dataset.linkId));});}
function bind(){
  $$('.nav').forEach(b=>b.onclick=()=>{state.view=b.dataset.view;state.type=null;state.limit=180;render();window.scrollTo({top:0,behavior:'smooth'});});
  $('#globalSearch').oninput=e=>{state.query=e.target.value;state.limit=180;render();};
  $('#sortSelect').onchange=e=>{state.sort=e.target.value;render();};
  $('#themeBtn').onclick=()=>{document.documentElement.classList.toggle('light');try{localStorage.setItem('erDexTheme',document.documentElement.classList.contains('light')?'light':'dark');}catch(e){}};
  $('#homeBtn').onclick=()=>{state.view='pokemon';state.query='';state.type=null;$('#globalSearch').value='';render();window.scrollTo({top:0,behavior:'smooth'});};
  $('#modalClose').onclick=closeModal;$('#modalBackdrop').onclick=e=>{if(e.target===$('#modalBackdrop'))closeModal();};
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)){e.preventDefault();$('#globalSearch').focus();}});
}
async function init(){
  try{if(localStorage.getItem('erDexTheme')==='light')document.documentElement.classList.add('light');}catch(e){} bind();prepare();render();
  const base=await loadBase();state.data=base;prepare();render();
  if(base){setStatus('',`연결 완료 · ${state.col.species.length.toLocaleString()}종/폼 · ROM SHA-256 ${KO.meta.romSha256.slice(0,12)}…`);}else{setStatus('error','공개 기본 데이터 연결 실패 · 한국어 ROM 텍스트 데이터만 표시 중');}
}
init();
})();
